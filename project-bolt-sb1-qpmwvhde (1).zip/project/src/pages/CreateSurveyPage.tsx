import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { PlusCircle, Edit, Trash2, Type, CheckSquare, List, Menu, Star, AlignJustify, ArrowLeft, Save } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// Define survey question types
type QuestionType = 'text' | 'multipleChoice' | 'checkbox' | 'rating' | 'dropdown';

interface Question {
  id: string;
  type: QuestionType;
  title: string;
  required: boolean;
  options?: string[];
}

const CreateSurveyPage: React.FC = () => {
  const navigate = useNavigate();
  const [surveyTitle, setSurveyTitle] = useState('Untitled Survey');
  const [surveyDescription, setSurveyDescription] = useState('');
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: '1',
      type: 'text',
      title: 'What is your name?',
      required: true,
    },
    {
      id: '2',
      type: 'multipleChoice',
      title: 'How satisfied are you with our product?',
      required: true,
      options: ['Very satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very dissatisfied'],
    },
  ]);
  const [activeQuestionId, setActiveQuestionId] = useState<string | null>('1');

  // Function to add a new question
  const addQuestion = (type: QuestionType) => {
    const newQuestion: Question = {
      id: Date.now().toString(),
      type,
      title: 'New Question',
      required: false,
    };

    if (type === 'multipleChoice' || type === 'checkbox' || type === 'dropdown') {
      newQuestion.options = ['Option 1', 'Option 2', 'Option 3'];
    }

    setQuestions([...questions, newQuestion]);
    setActiveQuestionId(newQuestion.id);
  };

  // Function to update a question
  const updateQuestion = (id: string, updates: Partial<Question>) => {
    setQuestions(
      questions.map((question) => 
        question.id === id ? { ...question, ...updates } : question
      )
    );
  };

  // Function to delete a question
  const deleteQuestion = (id: string) => {
    setQuestions(questions.filter((question) => question.id !== id));
    if (activeQuestionId === id) {
      setActiveQuestionId(questions.length > 1 ? questions[0].id : null);
    }
  };

  // Function to handle drag and drop reordering
  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    
    const items = Array.from(questions);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    setQuestions(items);
  };

  // Function to add an option to a question
  const addOption = (questionId: string) => {
    setQuestions(
      questions.map((question) => {
        if (question.id === questionId && question.options) {
          return {
            ...question,
            options: [...question.options, `Option ${question.options.length + 1}`],
          };
        }
        return question;
      })
    );
  };

  // Function to update an option
  const updateOption = (questionId: string, optionIndex: number, value: string) => {
    setQuestions(
      questions.map((question) => {
        if (question.id === questionId && question.options) {
          const newOptions = [...question.options];
          newOptions[optionIndex] = value;
          return { ...question, options: newOptions };
        }
        return question;
      })
    );
  };

  // Function to delete an option
  const deleteOption = (questionId: string, optionIndex: number) => {
    setQuestions(
      questions.map((question) => {
        if (question.id === questionId && question.options && question.options.length > 1) {
          const newOptions = [...question.options];
          newOptions.splice(optionIndex, 1);
          return { ...question, options: newOptions };
        }
        return question;
      })
    );
  };

  // Function to save the survey
  const saveSurvey = () => {
    // In a real app, this would save to backend
    console.log('Saving survey:', { title: surveyTitle, description: surveyDescription, questions });
    
    // Navigate to dashboard
    navigate('/dashboard');
  };

  return (
    <div className="py-6 bg-gray-50 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top navigation */}
        <div className="flex justify-between items-center mb-6">
          <button 
            onClick={() => navigate(-1)} 
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft size={16} className="mr-1" />
            Back
          </button>
          <button
            onClick={saveSurvey}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Save size={16} className="mr-2" />
            Save Survey
          </button>
        </div>

        {/* Survey title and description */}
        <div className="bg-white shadow-sm rounded-lg mb-6 p-6">
          <input
            type="text"
            value={surveyTitle}
            onChange={(e) => setSurveyTitle(e.target.value)}
            className="text-3xl font-bold text-gray-900 border-none focus:ring-0 w-full mb-2"
            placeholder="Survey Title"
          />
          <textarea
            value={surveyDescription}
            onChange={(e) => setSurveyDescription(e.target.value)}
            className="text-base text-gray-500 border-none focus:ring-0 w-full resize-none"
            placeholder="Survey Description (optional)"
            rows={2}
          />
        </div>

        {/* Question builder area */}
        <div className="flex gap-6">
          {/* Questions list */}
          <div className="w-3/4">
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="questions">
                {(provided) => (
                  <div
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className="space-y-4"
                  >
                    {questions.map((question, index) => (
                      <Draggable key={question.id} draggableId={question.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            className={`bg-white shadow-sm rounded-lg p-6 ${
                              activeQuestionId === question.id ? 'ring-2 ring-indigo-500' : ''
                            }`}
                            onClick={() => setActiveQuestionId(question.id)}
                          >
                            <div className="flex justify-between items-start mb-4">
                              <div className="flex-grow">
                                <input
                                  type="text"
                                  value={question.title}
                                  onChange={(e) => updateQuestion(question.id, { title: e.target.value })}
                                  className="text-lg font-medium text-gray-900 border-none focus:ring-0 w-full"
                                  placeholder="Question Title"
                                />
                                
                                <div className="mt-1 flex items-center">
                                  <span className="text-sm text-gray-500 mr-2">
                                    {question.type === 'text' ? 'Short answer' :
                                     question.type === 'multipleChoice' ? 'Multiple choice' :
                                     question.type === 'checkbox' ? 'Checkboxes' :
                                     question.type === 'rating' ? 'Rating' : 'Dropdown'}
                                  </span>
                                  
                                  <label className="flex items-center text-sm text-gray-500">
                                    <input
                                      type="checkbox"
                                      checked={question.required}
                                      onChange={(e) => updateQuestion(question.id, { required: e.target.checked })}
                                      className="mr-1 h-4 w-4 text-indigo-600 rounded"
                                    />
                                    Required
                                  </label>
                                </div>
                              </div>
                              
                              <div className="flex items-center">
                                <div {...provided.dragHandleProps} className="cursor-move p-1">
                                  <Menu size={18} className="text-gray-400" />
                                </div>
                                <button 
                                  onClick={() => deleteQuestion(question.id)}
                                  className="p-1 text-gray-400 hover:text-red-500"
                                >
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </div>
                            
                            {/* Question preview */}
                            <div className="mt-4">
                              {question.type === 'text' && (
                                <input
                                  type="text"
                                  disabled
                                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 bg-gray-50"
                                  placeholder="Short answer text"
                                />
                              )}
                              
                              {question.type === 'multipleChoice' && question.options && (
                                <div className="space-y-2">
                                  {question.options.map((option, optionIndex) => (
                                    <div key={optionIndex} className="flex items-center">
                                      <input
                                        type="radio"
                                        disabled
                                        className="h-4 w-4 text-indigo-600 border-gray-300"
                                      />
                                      <input
                                        type="text"
                                        value={option}
                                        onChange={(e) => updateOption(question.id, optionIndex, e.target.value)}
                                        className="ml-2 block w-full border-none focus:ring-0"
                                        placeholder={`Option ${optionIndex + 1}`}
                                      />
                                      {question.options && question.options.length > 1 && (
                                        <button
                                          onClick={() => deleteOption(question.id, optionIndex)}
                                          className="p-1 text-gray-400 hover:text-red-500"
                                        >
                                          <Trash2 size={16} />
                                        </button>
                                      )}
                                    </div>
                                  ))}
                                  <button
                                    onClick={() => addOption(question.id)}
                                    className="mt-2 text-sm text-indigo-600 hover:text-indigo-800 flex items-center"
                                  >
                                    <PlusCircle size={16} className="mr-1" />
                                    Add Option
                                  </button>
                                </div>
                              )}
                              
                              {question.type === 'checkbox' && question.options && (
                                <div className="space-y-2">
                                  {question.options.map((option, optionIndex) => (
                                    <div key={optionIndex} className="flex items-center">
                                      <input
                                        type="checkbox"
                                        disabled
                                        className="h-4 w-4 text-indigo-600 rounded"
                                      />
                                      <input
                                        type="text"
                                        value={option}
                                        onChange={(e) => updateOption(question.id, optionIndex, e.target.value)}
                                        className="ml-2 block w-full border-none focus:ring-0"
                                        placeholder={`Option ${optionIndex + 1}`}
                                      />
                                      {question.options && question.options.length > 1 && (
                                        <button
                                          onClick={() => deleteOption(question.id, optionIndex)}
                                          className="p-1 text-gray-400 hover:text-red-500"
                                        >
                                          <Trash2 size={16} />
                                        </button>
                                      )}
                                    </div>
                                  ))}
                                  <button
                                    onClick={() => addOption(question.id)}
                                    className="mt-2 text-sm text-indigo-600 hover:text-indigo-800 flex items-center"
                                  >
                                    <PlusCircle size={16} className="mr-1" />
                                    Add Option
                                  </button>
                                </div>
                              )}
                              
                              {question.type === 'rating' && (
                                <div className="flex items-center space-x-1 mt-2">
                                  {[1, 2, 3, 4, 5].map((rating) => (
                                    <button
                                      key={rating}
                                      className="h-8 w-8 flex items-center justify-center rounded-full border border-gray-300 text-gray-700 hover:bg-gray-100"
                                    >
                                      {rating}
                                    </button>
                                  ))}
                                </div>
                              )}
                              
                              {question.type === 'dropdown' && question.options && (
                                <div>
                                  <select
                                    disabled
                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 bg-gray-50"
                                  >
                                    <option value="">Select an option</option>
                                    {question.options.map((option, optionIndex) => (
                                      <option key={optionIndex} value={option}>
                                        {option}
                                      </option>
                                    ))}
                                  </select>
                                  
                                  <div className="mt-2 space-y-2">
                                    {question.options.map((option, optionIndex) => (
                                      <div key={optionIndex} className="flex items-center">
                                        <input
                                          type="text"
                                          value={option}
                                          onChange={(e) => updateOption(question.id, optionIndex, e.target.value)}
                                          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                          placeholder={`Option ${optionIndex + 1}`}
                                        />
                                        {question.options && question.options.length > 1 && (
                                          <button
                                            onClick={() => deleteOption(question.id, optionIndex)}
                                            className="ml-2 p-1 text-gray-400 hover:text-red-500"
                                          >
                                            <Trash2 size={16} />
                                          </button>
                                        )}
                                      </div>
                                    ))}
                                    <button
                                      onClick={() => addOption(question.id)}
                                      className="mt-2 text-sm text-indigo-600 hover:text-indigo-800 flex items-center"
                                    >
                                      <PlusCircle size={16} className="mr-1" />
                                      Add Option
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </div>

          {/* Question type toolbox */}
          <div className="w-1/4">
            <div className="bg-white shadow-sm rounded-lg p-4 sticky top-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Add Question</h3>
              <div className="space-y-2">
                <button
                  onClick={() => addQuestion('text')}
                  className="flex items-center w-full px-3 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 rounded-md"
                >
                  <Type size={16} className="mr-2 text-gray-500" />
                  Text
                </button>
                <button
                  onClick={() => addQuestion('multipleChoice')}
                  className="flex items-center w-full px-3 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 rounded-md"
                >
                  <CheckSquare size={16} className="mr-2 text-gray-500" />
                  Multiple Choice
                </button>
                <button
                  onClick={() => addQuestion('checkbox')}
                  className="flex items-center w-full px-3 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 rounded-md"
                >
                  <CheckSquare size={16} className="mr-2 text-gray-500" />
                  Checkboxes
                </button>
                <button
                  onClick={() => addQuestion('dropdown')}
                  className="flex items-center w-full px-3 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 rounded-md"
                >
                  <List size={16} className="mr-2 text-gray-500" />
                  Dropdown
                </button>
                <button
                  onClick={() => addQuestion('rating')}
                  className="flex items-center w-full px-3 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 rounded-md"
                >
                  <Star size={16} className="mr-2 text-gray-500" />
                  Rating
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateSurveyPage;
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Send } from 'lucide-react';

// Mock data for a survey
const mockSurvey = {
  id: '1',
  title: 'Customer Satisfaction Survey',
  description: 'Please help us improve our products and services by taking this short survey.',
  questions: [
    {
      id: '1',
      type: 'text',
      title: 'What is your name?',
      required: true,
    },
    {
      id: '2',
      type: 'multipleChoice',
      title: 'How satisfied are you with our product?',
      required: true,
      options: ['Very satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very dissatisfied'],
    },
    {
      id: '3',
      type: 'text',
      title: 'What features do you like most about our product?',
      required: false,
    },
    {
      id: '4',
      type: 'multipleChoice',
      title: 'How likely are you to recommend our product to a friend or colleague?',
      required: true,
      options: ['Very likely', 'Likely', 'Neutral', 'Unlikely', 'Very unlikely'],
    },
    {
      id: '5',
      type: 'checkbox',
      title: 'Which features would you like to see improved? (Select all that apply)',
      required: false,
      options: ['User Interface', 'Performance', 'Pricing', 'Customer Support', 'Documentation'],
    },
  ],
};

const ViewSurveyPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [submitted, setSubmitted] = useState(false);
  
  // In a real app, we would fetch the survey data from an API
  const survey = mockSurvey;
  const currentQuestion = survey.questions[currentQuestionIndex];
  
  const updateAnswer = (questionId: string, value: any) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: value,
    }));
  };
  
  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>, questionId: string) => {
    updateAnswer(questionId, e.target.value);
  };
  
  const handleMultipleChoiceChange = (e: React.ChangeEvent<HTMLInputElement>, questionId: string) => {
    updateAnswer(questionId, e.target.value);
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>, questionId: string, option: string) => {
    const currentValue = answers[questionId] || [];
    if (e.target.checked) {
      updateAnswer(questionId, [...currentValue, option]);
    } else {
      updateAnswer(questionId, currentValue.filter((item: string) => item !== option));
    }
  };
  
  const isQuestionAnswered = (questionId: string): boolean => {
    if (!survey.questions.find(q => q.id === questionId)?.required) {
      return true;
    }
    
    const answer = answers[questionId];
    if (answer === undefined) return false;
    if (Array.isArray(answer)) return answer.length > 0;
    return answer !== '';
  };
  
  const canGoNext = isQuestionAnswered(currentQuestion.id);
  
  const goToPrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };
  
  const goToNext = () => {
    if (canGoNext && currentQuestionIndex < survey.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };
  
  const handleSubmit = () => {
    // In a real app, we would send the answers to an API
    console.log('Submitting answers:', answers);
    setSubmitted(true);
    
    // After a delay, redirect to a thank you page or back to the homepage
    setTimeout(() => {
      navigate('/');
    }, 3000);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center px-4">
        <div className="bg-white shadow-lg rounded-lg p-8 max-w-md w-full text-center">
          <svg 
            className="mx-auto h-12 w-12 text-green-500" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              d="M5 13l4 4L19 7"
            />
          </svg>
          <h2 className="mt-4 text-2xl font-bold text-gray-900">Thank you for your feedback!</h2>
          <p className="mt-2 text-gray-600">Your responses have been submitted successfully.</p>
          <p className="mt-4 text-sm text-gray-500">Redirecting you shortly...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Progress indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-sm text-gray-500 mb-2">
            <span>Question {currentQuestionIndex + 1} of {survey.questions.length}</span>
            <span>{Math.round(((currentQuestionIndex + 1) / survey.questions.length) * 100)}% completed</span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full">
            <div 
              className="h-2 bg-indigo-600 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestionIndex + 1) / survey.questions.length) * 100}%` }}
            ></div>
          </div>
        </div>
        
        {/* Survey header - only show on first question */}
        {currentQuestionIndex === 0 && (
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">{survey.title}</h1>
            {survey.description && (
              <p className="text-gray-600">{survey.description}</p>
            )}
          </div>
        )}
        
        {/* Question card */}
        <div className="bg-white shadow-lg rounded-lg p-8 mb-8 transition-all duration-300 transform">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">
            {currentQuestion.title}
            {currentQuestion.required && (
              <span className="text-red-500 ml-1">*</span>
            )}
          </h2>
          
          {/* Question content based on type */}
          <div className="mb-8">
            {currentQuestion.type === 'text' && (
              <input
                type="text"
                value={answers[currentQuestion.id] || ''}
                onChange={(e) => handleTextChange(e, currentQuestion.id)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Your answer"
                required={currentQuestion.required}
              />
            )}
            
            {currentQuestion.type === 'multipleChoice' && currentQuestion.options && (
              <div className="space-y-4">
                {currentQuestion.options.map((option, index) => (
                  <label key={index} className="flex items-start">
                    <input
                      type="radio"
                      name={`question-${currentQuestion.id}`}
                      value={option}
                      checked={answers[currentQuestion.id] === option}
                      onChange={(e) => handleMultipleChoiceChange(e, currentQuestion.id)}
                      className="mt-1 h-4 w-4 text-indigo-600 border-gray-300 focus:ring-indigo-500"
                    />
                    <span className="ml-3 text-gray-700">{option}</span>
                  </label>
                ))}
              </div>
            )}
            
            {currentQuestion.type === 'checkbox' && currentQuestion.options && (
              <div className="space-y-4">
                {currentQuestion.options.map((option, index) => (
                  <label key={index} className="flex items-start">
                    <input
                      type="checkbox"
                      value={option}
                      checked={(answers[currentQuestion.id] || []).includes(option)}
                      onChange={(e) => handleCheckboxChange(e, currentQuestion.id, option)}
                      className="mt-1 h-4 w-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500"
                    />
                    <span className="ml-3 text-gray-700">{option}</span>
                  </label>
                ))}
              </div>
            )}
          </div>
          
          {/* Navigation buttons */}
          <div className="flex justify-between">
            <button
              onClick={goToPrevious}
              disabled={currentQuestionIndex === 0}
              className={`flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium ${
                currentQuestionIndex === 0 
                  ? 'opacity-50 cursor-not-allowed text-gray-400' 
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              <ChevronLeft size={16} className="mr-1" />
              Previous
            </button>
            
            {currentQuestionIndex < survey.questions.length - 1 ? (
              <button
                onClick={goToNext}
                disabled={!canGoNext}
                className={`flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium ${
                  canGoNext
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700' 
                    : 'bg-indigo-300 text-white cursor-not-allowed'
                }`}
              >
                Next
                <ChevronRight size={16} className="ml-1" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={!canGoNext}
                className={`flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium ${
                  canGoNext
                    ? 'bg-green-600 text-white hover:bg-green-700' 
                    : 'bg-green-300 text-white cursor-not-allowed'
                }`}
              >
                Submit
                <Send size={16} className="ml-1" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewSurveyPage;
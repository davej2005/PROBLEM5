import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Download, Share2, Filter, List, BarChart2 } from 'lucide-react';

// Mock data for survey results
const mockSurvey = {
  id: '1',
  title: 'Customer Satisfaction Survey',
  description: 'Results from our customer satisfaction survey.',
  totalResponses: 245,
  completionRate: 87,
  averageTime: '2m 34s',
  questions: [
    {
      id: '1',
      type: 'text',
      title: 'What is your name?',
      responses: ['John Doe', 'Jane Smith', 'Mike Johnson', 'Sarah Williams', 'Chris Brown'],
    },
    {
      id: '2',
      type: 'multipleChoice',
      title: 'How satisfied are you with our product?',
      data: [
        { name: 'Very satisfied', value: 120 },
        { name: 'Satisfied', value: 80 },
        { name: 'Neutral', value: 30 },
        { name: 'Dissatisfied', value: 12 },
        { name: 'Very dissatisfied', value: 3 },
      ],
    },
    {
      id: '3',
      type: 'text',
      title: 'What features do you like most about our product?',
      responses: ['User interface', 'Performance', 'Customer support', 'Documentation', 'Price'],
    },
    {
      id: '4',
      type: 'multipleChoice',
      title: 'How likely are you to recommend our product to a friend or colleague?',
      data: [
        { name: 'Very likely', value: 135 },
        { name: 'Likely', value: 65 },
        { name: 'Neutral', value: 25 },
        { name: 'Unlikely', value: 15 },
        { name: 'Very unlikely', value: 5 },
      ],
    },
    {
      id: '5',
      type: 'checkbox',
      title: 'Which features would you like to see improved? (Select all that apply)',
      data: [
        { name: 'User Interface', value: 180 },
        { name: 'Performance', value: 120 },
        { name: 'Pricing', value: 90 },
        { name: 'Customer Support', value: 60 },
        { name: 'Documentation', value: 100 },
      ],
    },
  ],
};

// Colors for charts
const COLORS = ['#6366F1', '#8B5CF6', '#EC4899', '#F43F5E', '#F97316'];

const ResultsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [viewType, setViewType] = useState<'chart' | 'list'>('chart');
  
  // In a real app, we would fetch the survey results from an API
  const survey = mockSurvey;
  
  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{survey.title} - Results</h1>
          <p className="text-gray-600">{survey.totalResponses} responses</p>
        </div>
        <div className="flex space-x-3">
          <button className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            <div className="flex items-center">
              <Filter size={16} className="mr-2" />
              Filter
            </div>
          </button>
          <button className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            <div className="flex items-center">
              <Share2 size={16} className="mr-2" />
              Share
            </div>
          </button>
          <button className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            <div className="flex items-center">
              <Download size={16} className="mr-2" />
              Export
            </div>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3 mb-8">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <dt className="text-sm font-medium text-gray-500 truncate">Total Responses</dt>
            <dd className="mt-1 text-3xl font-semibold text-gray-900">{survey.totalResponses}</dd>
          </div>
        </div>
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <dt className="text-sm font-medium text-gray-500 truncate">Completion Rate</dt>
            <dd className="mt-1 text-3xl font-semibold text-gray-900">{survey.completionRate}%</dd>
          </div>
        </div>
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <dt className="text-sm font-medium text-gray-500 truncate">Average Completion Time</dt>
            <dd className="mt-1 text-3xl font-semibold text-gray-900">{survey.averageTime}</dd>
          </div>
        </div>
      </div>

      {/* Toggle view type */}
      <div className="flex justify-end mb-6">
        <div className="inline-flex shadow-sm rounded-md">
          <button
            type="button"
            onClick={() => setViewType('chart')}
            className={`relative inline-flex items-center px-4 py-2 rounded-l-md border border-gray-300 ${
              viewType === 'chart'
                ? 'bg-indigo-50 text-indigo-600'
                : 'bg-white text-gray-700'
            } text-sm font-medium hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500`}
          >
            <BarChart2 size={16} className="mr-2" />
            Charts
          </button>
          <button
            type="button"
            onClick={() => setViewType('list')}
            className={`relative inline-flex items-center px-4 py-2 rounded-r-md border border-gray-300 ${
              viewType === 'list'
                ? 'bg-indigo-50 text-indigo-600'
                : 'bg-white text-gray-700'
            } text-sm font-medium hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500`}
          >
            <List size={16} className="mr-2" />
            List
          </button>
        </div>
      </div>

      {/* Results */}
      <div className="space-y-8">
        {survey.questions.map((question) => (
          <div key={question.id} className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                {question.title}
              </h3>
            </div>
            <div className="px-4 py-5 sm:p-6">
              {/* Text responses */}
              {question.type === 'text' && (
                <div className="space-y-4">
                  {viewType === 'list' ? (
                    <ul className="border border-gray-200 rounded-md divide-y divide-gray-200">
                      {question.responses?.map((response, index) => (
                        <li key={index} className="pl-3 pr-4 py-3 flex items-center justify-between text-sm">
                          <div className="w-0 flex-1 flex items-center">
                            <span className="flex-1 w-0 truncate text-gray-700">{response}</span>
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500 italic">Text responses are only available in list view.</p>
                  )}
                </div>
              )}

              {/* Multiple choice and checkbox responses */}
              {(question.type === 'multipleChoice' || question.type === 'checkbox') && question.data && (
                <div>
                  {viewType === 'chart' ? (
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        {question.type === 'multipleChoice' ? (
                          <PieChart>
                            <Pie
                              data={question.data}
                              cx="50%"
                              cy="50%"
                              labelLine={true}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            >
                              {question.data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        ) : (
                          <BarChart
                            data={question.data}
                            margin={{
                              top: 20,
                              right: 30,
                              left: 20,
                              bottom: 5,
                            }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Bar dataKey="value" fill="#6366F1" />
                          </BarChart>
                        )}
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Option
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Count
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Percentage
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {question.data.map((item, index) => {
                          const total = question.data.reduce((sum, item) => sum + item.value, 0);
                          const percentage = ((item.value / total) * 100).toFixed(1);
                          
                          return (
                            <tr key={index}>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.name}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.value}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{percentage}%</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResultsPage;
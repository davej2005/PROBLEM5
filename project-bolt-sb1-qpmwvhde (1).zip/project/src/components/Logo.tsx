import React from 'react';
import { BarChart2 } from 'lucide-react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center justify-center h-8 w-8 bg-indigo-600 rounded-md">
      <BarChart2 size={20} className="text-white" />
    </div>
  );
};

export default Logo;
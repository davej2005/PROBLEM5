import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import CreateSurveyPage from './pages/CreateSurveyPage';
import ViewSurveyPage from './pages/ViewSurveyPage';
import ResultsPage from './pages/ResultsPage';
import NotFoundPage from './pages/NotFoundPage';
import Layout from './components/Layout';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout><HomePage /></Layout>} />
        <Route path="/dashboard" element={<Layout><DashboardPage /></Layout>} />
        <Route path="/create" element={<Layout><CreateSurveyPage /></Layout>} />
        <Route path="/survey/:id" element={<Layout hideNav={true}><ViewSurveyPage /></Layout>} />
        <Route path="/results/:id" element={<Layout><ResultsPage /></Layout>} />
        <Route path="*" element={<Layout><NotFoundPage /></Layout>} />
      </Routes>
    </Router>
  );
}

export default App;